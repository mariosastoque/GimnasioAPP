package com.gimnasio.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        // Recursos estáticos y páginas públicas permitidas
                        .requestMatchers("/css/**", "/js/**", "/images/**", "/login").permitAll()

                        // Usamos hasAuthority para leer exactamente los strings "ADMIN", "ENTRENADOR", etc.
                        .requestMatchers("/admin/**").hasAuthority("ADMIN")
                        .requestMatchers("/entrenador/**").hasAuthority("ENTRENADOR")
                        .requestMatchers("/cliente/**").hasAuthority("CLIENTE")
                        .requestMatchers("/mantenimiento/**").hasAuthority("MANTENIMIENTO")

                        // Cualquier otra solicitud requiere autenticación previa
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/admin/dashboard", true) // <--- Redirige directo al dashboard del admin
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}