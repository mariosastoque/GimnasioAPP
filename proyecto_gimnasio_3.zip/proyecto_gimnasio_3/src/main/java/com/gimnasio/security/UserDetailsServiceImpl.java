package com.gimnasio.security;

import com.gimnasio.model.Usuario;
import com.gimnasio.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado con el correo: " + email));

        // Creamos la autoridad usando el rol del usuario (ej. "ADMIN")
        // Asegúrate de que usuario.getRol() retorne exactamente "ADMIN", "ENTRENADOR", etc.
        var authorities = java.util.Collections.singletonList(
                new org.springframework.security.core.authority.SimpleGrantedAuthority(usuario.getRol())
        );

        return new User(
                usuario.getEmail(),
                usuario.getPassword(),
                authorities // <--- ¡Aquí van las autoridades!
        );
    }
}