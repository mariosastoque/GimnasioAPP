package com.gimnasio.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "mantenimientos")
public class Mantenimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String equipoOZona; // Ej. Caminadora Pro #3 o Zona de Poleas

    @Column(columnDefinition = "TEXT")
    private String descripcionFalla;

    private String prioridad; // Ej. Baja, Media, Alta, Urgente
    private String estado;    // Ej. Pendiente, En Proceso, Resuelto
    private LocalDate fechaReporte = LocalDate.now();

    public Mantenimiento() {}

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEquipoOZona() { return equipoOZona; }
    public void setEquipoOZona(String equipoOZona) { this.equipoOZona = equipoOZona; }

    public String getDescripcionFalla() { return descripcionFalla; }
    public void setDescripcionFalla(String descripcionFalla) { this.descripcionFalla = descripcionFalla; }

    public String getPrioridad() { return prioridad; }
    public void setPrioridad(String prioridad) { this.prioridad = prioridad; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public LocalDate getFechaReporte() { return fechaReporte; }
    public void setFechaReporte(LocalDate fechaReporte) { this.fechaReporte = fechaReporte; }
}