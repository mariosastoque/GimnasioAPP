package com.gimnasio.model;

public class NodoMantenimiento {
    private Mantenimiento mantenimiento;
    private NodoMantenimiento siguiente;

    public NodoMantenimiento(Mantenimiento mantenimiento) {
        this.mantenimiento = mantenimiento;
        this.siguiente = null;
    }

    // Getters y Setters
    public Mantenimiento getMantenimiento() { return mantenimiento; }
    public void setMantenimiento(Mantenimiento mantenimiento) { this.mantenimiento = mantenimiento; }

    public NodoMantenimiento getSiguiente() { return siguiente; }
    public void setSiguiente(NodoMantenimiento siguiente) { this.siguiente = siguiente; }
}