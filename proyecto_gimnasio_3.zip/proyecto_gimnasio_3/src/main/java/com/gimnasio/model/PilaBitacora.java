package com.gimnasio.model; // O tu paquete correspondiente

import java.util.ArrayList;
import java.util.List;

public class PilaBitacora {
    private NodoMantenimiento cima;
    private int tamanio;

    public PilaBitacora() {
        this.cima = null;
        this.tamanio = 0;
    }

    // Apilar: Inserta un nuevo elemento resuelto en la cima de la pila
    public void apilar(Mantenimiento mantenimiento) {
        NodoMantenimiento nuevoNodo = new NodoMantenimiento(mantenimiento);
        nuevoNodo.setSiguiente(cima);
        cima = nuevoNodo;
        tamanio++;
    }

    // Desapilar: Saca el elemento de la cima
    public Mantenimiento desapilar() {
        if (cima == null) return null;
        Mantenimiento item = cima.getMantenimiento();
        cima = cima.getSiguiente();
        tamanio--;
        return item;
    }

    // Convertir la pila a lista para mostrarla fácilmente en la tabla de Thymeleaf
    public List<Mantenimiento> obtenerElementosComoLista() {
        List<Mantenimiento> lista = new ArrayList<>();
        NodoMantenimiento actual = cima;
        while (actual != null) {
            lista.add(actual.getMantenimiento());
            actual = actual.getSiguiente();
        }
        return lista;
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public int getTamanio() {
        return tamanio;
    }
}