package com.gimnasio.model; // O tu paquete correspondiente

import java.util.ArrayList;
import java.util.List;

public class ColaMantenimiento {
    private NodoMantenimiento frente;
    private NodoMantenimiento fin;
    private int tamanio;

    public ColaMantenimiento() {
        this.frente = null;
        this.fin = null;
        this.tamanio = 0;
    }

    // Encolar: Agrega al final de la cola
    public void encolar(Mantenimiento mantenimiento) {
        NodoMantenimiento nuevoNodo = new NodoMantenimiento(mantenimiento);
        if (fin == null) {
            frente = fin = nuevoNodo;
        } else {
            fin.setSiguiente(nuevoNodo);
            fin = nuevoNodo;
        }
        tamanio++;
    }

    // Desencolar: Saca el elemento del frente (el que lleva más tiempo esperando)
    public Mantenimiento desencolar() {
        if (frente == null) return null;
        Mantenimiento item = frente.getMantenimiento();
        frente = frente.getSiguiente();
        if (frente == null) {
            fin = null;
        }
        tamanio--;
        return item;
    }

    // Método auxiliar para convertir la cola en una lista normal de Java (ideal para pintar en Thymeleaf)
    public List<Mantenimiento> obtenerElementosComoLista() {
        List<Mantenimiento> lista = new ArrayList<>();
        NodoMantenimiento actual = frente;
        while (actual != null) {
            lista.add(actual.getMantenimiento());
            actual = actual.getSiguiente();
        }
        return lista;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public int getTamanio() {
        return tamanio;
    }
}