package com.gimnasio.admin.controller;

import com.gimnasio.admin.service.AdminService;
import com.gimnasio.model.Maquina;
import com.gimnasio.model.Rutina;
import com.gimnasio.admin.service.RutinaService;
import com.gimnasio.admin.service.MaquinaService;
import com.gimnasio.model.Usuario;
import com.gimnasio.model.Mantenimiento;
import com.gimnasio.admin.service.MantenimientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/dashboard")
    public String dashboardAdmin(Model model) {
        model.addAttribute("usuarios", adminService.obtenerTodosLosUsuarios());
        return "admin/dashboard";
    }

    // Muestra el formulario para crear un nuevo usuario
    @GetMapping("/usuarios/nuevo")
    public String mostrarFormularioCrearUsuario(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "admin/nuevo-usuario";
    }

    // Recibe los datos del formulario y los guarda en la BD
    @PostMapping("/usuarios/guardar")
    public String guardarUsuario(@ModelAttribute Usuario usuario) {
        adminService.registrarUsuario(usuario);
        return "redirect:/admin/dashboard";
    }

    // Muestra la vista detallada de finanzas del gimnasio
    @GetMapping("/finanzas")
    public String verFinanzas(Model model) {
        List<Usuario> usuarios = adminService.obtenerTodosLosUsuarios();
        long totalClientes = usuarios.stream().filter(u -> "CLIENTE".equalsIgnoreCase(u.getRol())).count();

        model.addAttribute("usuarios", usuarios);
        model.addAttribute("totalSociosClientes", totalClientes);

        return "admin/finanzas";
    }

    // Muestra el directorio exclusivo de socios (clientes)
    @GetMapping("/socios")
    public String verSocios(Model model) {
        model.addAttribute("usuarios", adminService.obtenerTodosLosUsuarios());
        return "admin/socios";
    }

    @Autowired
    private MaquinaService maquinaService;

    // Muestra el directorio limpio de máquinas
    @GetMapping("/maquinas")
    public String verMaquinas(Model model) {
        model.addAttribute("maquinas", maquinaService.obtenerTodasLasMaquinas());
        return "admin/maquinas";
    }

    // Muestra el formulario para registrar una nueva máquina
    @GetMapping("/maquinas/nueva")
    public String mostrarFormularioNuevaMaquina(Model model) {
        model.addAttribute("maquina", new Maquina());
        return "admin/nueva-maquina";
    }

    // Guarda los datos del formulario y redirige al directorio
    @PostMapping("/maquinas/guardar")
    public String guardarMaquina(@ModelAttribute Maquina maquina) {
        maquinaService.guardarMaquina(maquina);
        return "redirect:/admin/maquinas";
    }

    @Autowired
    private MantenimientoService mantenimientoService;

    // Muestra la vista con la Cola de Ingresos y la Pila Bitácora
    @GetMapping("/mantenimiento")
    public String verMantenimiento(Model model) {
        model.addAttribute("ingresos", mantenimientoService.obtenerIngresos());
        model.addAttribute("bitacoras", mantenimientoService.obtenerBitacora());
        return "admin/mantenimiento";
    }

    @GetMapping("/mantenimiento/nuevo")
    public String mostrarFormularioNuevoMantenimiento(Model model) {
        model.addAttribute("mantenimiento", new Mantenimiento());
        return "admin/mantenimiento/mantenimiento";
    }

    @PostMapping("/mantenimiento/guardar")
    public String guardarMantenimiento(@ModelAttribute Mantenimiento mantenimiento) {
        mantenimientoService.guardarMantenimiento(mantenimiento);
        return "redirect:/admin/mantenimiento";
    }

    // Ruta para desencolar y pasar a la bitácora al hacer clic en "Atender"
    @PostMapping("/mantenimiento/atender")
    public String atenderMantenimiento() {
        mantenimientoService.atenderSiguienteMantenimiento();
        return "redirect:/admin/mantenimiento";
    }
    @Autowired
    private RutinaService rutinaService;

    // Muestra la vista de rutinas con los datos reales
    @GetMapping("/rutinas")
    public String verRutinas(Model model) {
        model.addAttribute("rutinas", rutinaService.obtenerTodasLasRutinas());
        return "admin/rutinas";
    }

    // Muestra el formulario con un objeto vacío
    @GetMapping("/rutinas/nueva")
    public String mostrarFormularioNuevaRutina(Model model) {
        model.addAttribute("rutina", new Rutina());
        return "admin/nueva-rutina";
    }

    // Recibe los datos y los guarda
    @PostMapping("/rutinas/guardar")
    public String guardarRutina(@ModelAttribute Rutina rutina) {
        rutinaService.guardarRutina(rutina);
        return "redirect:/admin/rutinas";
    }
}