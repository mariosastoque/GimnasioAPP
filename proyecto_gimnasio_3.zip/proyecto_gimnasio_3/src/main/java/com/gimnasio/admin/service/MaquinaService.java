package com.gimnasio.admin.service;

import com.gimnasio.model.Maquina;
import com.gimnasio.repository.MaquinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaquinaService {

    @Autowired
    private MaquinaRepository maquinaRepository;

    public List<Maquina> obtenerTodasLasMaquinas() {
        return maquinaRepository.findAll();
    }

    public void guardarMaquina(Maquina maquina) {
        maquinaRepository.save(maquina);
    }
}