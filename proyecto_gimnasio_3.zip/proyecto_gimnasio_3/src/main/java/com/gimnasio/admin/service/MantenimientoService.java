package com.gimnasio.admin.service;

import com.gimnasio.model.ColaMantenimiento;
import com.gimnasio.model.Mantenimiento;
import com.gimnasio.model.PilaBitacora;
import com.gimnasio.repository.MantenimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;

@Service
public class MantenimientoService {

    @Autowired
    private MantenimientoRepository mantenimientoRepository;

    private final ColaMantenimiento colaIngresos = new ColaMantenimiento();
    private final PilaBitacora pilaBitacora = new PilaBitacora();

    // Se ejecuta automáticamente al arrancar Spring Boot para reconstruir las estructuras desde la BD
    @PostConstruct
    public void inicializarEstructurasDesdeBD() {
        List<Mantenimiento> todos = mantenimientoRepository.findAll();

        for (Mantenimiento m : todos) {
            if ("Pendiente".equalsIgnoreCase(m.getEstado())) {
                colaIngresos.encolar(m);
            } else if ("Resuelto".equalsIgnoreCase(m.getEstado())) {
                pilaBitacora.apilar(m);
            }
        }
    }

    public List<Mantenimiento> obtenerIngresos() {
        return colaIngresos.obtenerElementosComoLista();
    }

    public List<Mantenimiento> obtenerBitacora() {
        return pilaBitacora.obtenerElementosComoLista();
    }

    // Guardar un nuevo reporte (entra a la Cola como Pendiente y se guarda en BD)
    public void guardarMantenimiento(Mantenimiento mantenimiento) {
        mantenimiento.setEstado("Pendiente");
        if (mantenimiento.getFechaReporte() == null) {
            mantenimiento.setFechaReporte(LocalDate.now());
        }

        // Persistir en Base de Datos
        mantenimientoRepository.save(mantenimiento);

        // Agregar a la estructura de Cola (FIFO)
        colaIngresos.encolar(mantenimiento);
    }

    // Atender / Resolver: Saca de la cola (FIFO), actualiza estado a Resuelto en BD y apila en la Pila (LIFO)
    public void atenderSiguienteMantenimiento() {
        Mantenimiento atendido = colaIngresos.desencolar();
        if (atendido != null) {
            atendido.setEstado("Resuelto");
            atendido.setFechaReporte(LocalDate.now());

            // Actualizar en Base de Datos
            mantenimientoRepository.save(atendido);

            // Apilar en la bitácora histórica
            pilaBitacora.apilar(atendido);
        }
    }

    // Devolver / Rectificar: Saca de la pila (LIFO), cambia a Pendiente en BD y re-encola en ingresos
    public void devolverUltimoMantenimiento() {
        Mantenimiento devuelto = pilaBitacora.desapilar();
        if (devuelto != null) {
            devuelto.setEstado("Pendiente");

            // Actualizar en Base de Datos
            mantenimientoRepository.save(devuelto);

            // Regresar a la cola de ingresos
            colaIngresos.encolar(devuelto);
        }
    }
}