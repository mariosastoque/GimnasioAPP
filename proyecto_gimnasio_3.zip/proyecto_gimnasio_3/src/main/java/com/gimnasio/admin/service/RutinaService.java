package com.gimnasio.admin.service;

import com.gimnasio.model.Rutina;
import com.gimnasio.repository.RutinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RutinaService {

    @Autowired
    private RutinaRepository rutinaRepository;

    public List<Rutina> obtenerTodasLasRutinas() {
        return rutinaRepository.findAll();
    }

    public void guardarRutina(Rutina rutina) {
        rutinaRepository.save(rutina);
    }
}