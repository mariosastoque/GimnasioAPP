package com.gimnasio.admin.service;

import com.gimnasio.model.Usuario;
import com.gimnasio.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioRepository.findAll();
    }

    // Nuevo método para registrar usuarios desde el panel del Admin
    public void registrarUsuario(Usuario usuario) {
        // Encriptamos la contraseña antes de guardarla por seguridad
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        // Aseguramos que el rol esté en mayúsculas por convención del sistema
        usuario.setRol(usuario.getRol().toUpperCase());
        usuarioRepository.save(usuario);
    }
}