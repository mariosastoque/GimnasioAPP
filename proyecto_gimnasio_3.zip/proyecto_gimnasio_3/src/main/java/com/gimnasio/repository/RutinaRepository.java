package com.gimnasio.repository; // Ajusta el paquete según tu estructura

import com.gimnasio.model.Rutina;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RutinaRepository extends JpaRepository<Rutina, Long> {
}