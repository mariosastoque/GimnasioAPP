package com.gimnasio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGimnasio3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
